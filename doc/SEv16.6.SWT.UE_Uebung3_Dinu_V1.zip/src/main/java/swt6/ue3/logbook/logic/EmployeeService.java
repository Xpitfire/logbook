package swt6.ue3.logbook.logic;

import swt6.ue3.logbook.domain.Employee;

/**
 * @author: Dinu Marius-Constantin
 * @date: 16.03.2016
 */
public interface EmployeeService extends AppService<Employee, Long> {
}
