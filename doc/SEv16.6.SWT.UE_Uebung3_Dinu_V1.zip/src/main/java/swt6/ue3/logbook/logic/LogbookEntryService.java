package swt6.ue3.logbook.logic;

import swt6.ue3.logbook.domain.LogbookEntry;

/**
 * @author: Dinu Marius-Constantin
 * @date: 16.03.2016
 */
public interface LogbookEntryService extends AppService<LogbookEntry, Long> {
}
