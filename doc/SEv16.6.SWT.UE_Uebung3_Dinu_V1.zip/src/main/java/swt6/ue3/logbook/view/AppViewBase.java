package swt6.ue3.logbook.view;

/**
 * @author: Dinu Marius-Constantin
 * @date: 17.03.2016
 */
public interface AppViewBase {

    void run();
    String getTitle();

}
