package swt6.ue3.logbook.view.exception;

/**
 * @author: Dinu Marius-Constantin
 * @date: 12.03.2016
 */
public class IllegalBooleanLogicException extends Throwable {
    public IllegalBooleanLogicException(String message) {
        super(message);
    }
}
