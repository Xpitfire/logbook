package swt6.ue3.logbook.view.exception;

/**
 * @author: Dinu Marius-Constantin
 * @date: 12.03.2016
 */
public class IllegalDateFormatException extends Throwable {
    public IllegalDateFormatException(String message) {
        super(message);
    }
}
